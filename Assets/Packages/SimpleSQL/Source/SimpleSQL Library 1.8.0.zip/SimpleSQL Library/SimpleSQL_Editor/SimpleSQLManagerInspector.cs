using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;

namespace SimpleSQL
{
    [CustomEditor(typeof(SimpleSQLManager))]
    public class SimpleSQLManagerInspector : Editor
    {
        protected const string DB_EXTENSION = "bytes";

        protected SimpleSQLManager _manager;
        protected List<string> _files = new List<string>();
        protected List<string> _guids = new List<string>();
        protected bool _needsRepainted;
        protected int _fileIndex;

        void OnEnable()
        {
            Style.Reset();

            SetTarget();
        }

        protected virtual void SetTarget()
        {
            _manager = (SimpleSQLManager)target;
        }

        public override void OnInspectorGUI()
        {
            if (_manager == null)
                SetTarget();

            if (_manager == null)
                return;

            GUILayout.BeginHorizontal();
            GUILayout.Label("Database File", GUILayout.Width(150.0f));
            TextAsset newAsset = (TextAsset)EditorGUILayout.ObjectField(_manager.databaseFile, typeof(TextAsset), false);
            if (newAsset != _manager.databaseFile)
            {
                _manager.databaseFile = newAsset;
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            GUILayout.Label("Override Base Path", GUILayout.Width(150.0f));
            string newOverrideBasePath = GUILayout.TextField(_manager.overrideBasePath);
            if (newOverrideBasePath != _manager.overrideBasePath)
            {
                _manager.overrideBasePath = newOverrideBasePath.Trim();
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal();
            bool highlight = false;
            if (_manager.changeWorkingName && _manager.workingName.Trim() == "")
            {
                highlight = true;
                Style.PushBackgroundColor(Color.yellow);
            }
            _manager.changeWorkingName = GUILayout.Toggle(_manager.changeWorkingName, (_manager.changeWorkingName ? "Change Working Name To" : "Change Working Name"), GUILayout.Width(150.0f));
            if (_manager.changeWorkingName)
            {
                string newWorkingName = GUILayout.TextField(_manager.workingName);
                if (newWorkingName != _manager.workingName)
                {
                    _manager.workingName = newWorkingName.Trim();
                }
            }
            if (highlight)
            {
                Style.PopBackgroundColor();
            }
            GUILayout.EndHorizontal();

            _manager.overwriteIfExists = GUILayout.Toggle(_manager.overwriteIfExists, "Overwrite If Exists", GUILayout.Width(150.0f));
            if (_manager.overwriteIfExists)
            {
                GUILayout.BeginHorizontal();
                GUILayout.Space(5.0f);

                GUILayout.BeginVertical(Style.warningStyle);

                GUILayout.Label("Warning! Overwriting the database if it exists on the \nclient device will wipe out any changes the user has \nmade since last running this scene.");
                GUILayout.Space(10.0f);
                GUILayout.Label("Overwriting is good for static data, but bad for \ndynamic data.");

                GUILayout.EndVertical();

                GUILayout.Space(5.0f);
                GUILayout.EndHorizontal();
            }

            _manager.debugTrace = GUILayout.Toggle(_manager.debugTrace, "Debug Trace");

            if (_needsRepainted)
            {
                Repaint();
                _needsRepainted = false;
            }

            //base.OnInspectorGUI();
        }
    }
}